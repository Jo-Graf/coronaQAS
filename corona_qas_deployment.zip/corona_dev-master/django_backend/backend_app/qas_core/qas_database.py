from typing import Optional, Dict, Any, List, Union
from backend_app.qas_core.qas_data_loader import QASDataLoader
from backend_app.qas_core.qas_database_variant import QASDatabaseVariant
from backend_app.qas_core.qas_document import QASDocument
from config import N_BATCHES


class QASDatabase:

    def __init__(self, variant: Optional[QASDatabaseVariant] = None, loader: Optional[QASDataLoader] = None):
        self.__variant = variant
        self.__data = []
        self.__loader = loader

    def set_variant(self, variant: QASDatabaseVariant):
        self.__variant = variant

    def get_variant(self) -> Optional[QASDatabaseVariant]:
        return self.__variant

    def set_loader(self, loader: QASDataLoader):
        self.__loader = loader

    def get_data(self,
                 identifiers: Optional[Union[str, List[str]]] = None,
                 query: Optional[Union[str, Dict]] = None
                 ) -> List[QASDocument]:
        return self.__variant.get_data(identifiers, query)

    def load_data(self, n_batches: int = N_BATCHES):

        for batch in range(n_batches):
            print('load batch: ' + str(batch) + ' of ' + str(n_batches))
            loaded, new_data = self.__loader.load_data(n_batches=n_batches, current_batch=batch)
            self.add_data(new_data)

        # loaded, new_data = self.__loader.load_data()
        # self.add_data(new_data)

    def add_data(self, data: List[QASDocument]):
        self.__variant.add_data(data)
        # self.__data.append(data)


