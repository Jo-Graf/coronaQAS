from abc import ABC


class QASAbstractPipeline(ABC):
    def __init__(self):
        pass
